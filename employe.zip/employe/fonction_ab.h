#include <gtk/gtk.h>
typedef struct
{
char cin[8];
date date;
int val;//1:p 0:a
}absent;
void afficher_employe_ab(GtkWidget *liste);
