#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "fonction_ab.h"
#include <gtk/gtk.h>
enum
{	
	CIN,
	NOM,
	PRENOM,
	COLUMNS
};
void afficher_employe_ab(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;


	GtkListStore *store;
	char nom[20];
	char prenom[20];
	char cin[8];
	char sexe[8];//1:homme 2:femme
	char adress[20];
	char password[20];
	char mail[30];
	char tel[8];

employe e;
FILE *f;
store=NULL;
store = gtk_tree_view_get_model(liste);

if (store==NULL)
{

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("cin",renderer,"text",CIN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("nom",renderer,"text",NOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",PRENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);



}
store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
f=fopen("employe.bin","rb");
if(f==NULL)
{
return;
}
else
{

f=fopen("employe.bin","rb");
		while(fread(&e,sizeof(employe),1,f)!=0)
{

/*char date_ambauche[15];
char cjour[10],cmois[10],cannee[10];
sprintf(cjour,"%d",e.date_amb.jour);
sprintf(cmois,"%d",e.date_amb.mois);
sprintf(cannee,"%d",e.date_amb.annee);
	strcpy(date_ambauche,cjour);
	strcat(date_ambauche,"-");
	strcat(date_ambauche,cmois);
	strcat(date_ambauche,"-");
	strcat(date_ambauche,cannee);*/
gtk_list_store_append(store,&iter);
gtk_list_store_set(store, &iter, CIN, e.cin, NOM, e.nom, PRENOM, e.prenom,-1);
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
g_object_unref (store);
}

}

