#include <gtk/gtk.h>


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_supprimer_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_modifier_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_button4_chercher_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button5_modifier_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton1_H_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_F_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton3_H_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton4_F_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button1_afficher_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_ajouter_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_homme_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_femme_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button1_checher1_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton1_sexe_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_nom_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton3_prenom_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_treeview2_ab_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button3_apply_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_valider_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data);
