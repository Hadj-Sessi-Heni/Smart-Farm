#include <gtk/gtk.h>


void
on_treeview2_ab_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);
void
on_button1_afficher_ch_clicked         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_supprimer_ch_clicked         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_modifier_ch_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button1_checher1_ch_clicked         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton1_H_ch_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_F_ch_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button1_ajouter_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_checkbutton1_sexe_ch_clicked        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_nom_ch_clicked         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton3_prenom_ch_clicked      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button4_chercher_ch_clicked         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton3_H_ch_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton4_F_ch_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button5_modifier_ch_clicked         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview1_ch_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_radiobutton2_femme_ch_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_homme_ch_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button1_ch_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button1_ajouter_ch_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton1_ch_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button3_apply_ch_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton2_ch_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button2_valider_ch_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button4_ch_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);
